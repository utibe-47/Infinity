

def calculate_level(prices, weights, basket_unit, basket_value):
    keys = list(prices.columns)
    for count, (index, row) in enumerate(prices.iterrows()):
        if count == 0:
            previous_prices = row
            continue
        top = []
        bottom = []
        for key in keys:
            top = basket_unit * row[key]
            bottom = basket_unit * previous_prices[key]
        new_basket_value = sum(top)/sum(bottom) * basket_value[0]
        basket_value.append(new_basket_value)


        weight = weights[key]

        basket_value = weight * price