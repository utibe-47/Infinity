from datetime import datetime
import numpy as np

from .level_calculations import calculate_level
from .portfolio import Portfolio
from .portfolio_weight_calculator import calculate_weight


class PortfolioMain:

    def __init__(self, prices, units):
        self.prices = prices
        self.units = units
        self._weights = None
        self.rebalancing_dates = None
        self.portfolio = Portfolio()

    def calculate_weights(self):
        self._weights = calculate_weight(self.units)

    def create_portfolio(self):
        self.calculate_weights()
        initial_tickers = self._get_tickers()
        self.used_weights = self._get_weights(0)
        self.rebalancing_dates = list(self.weights.index)[1:]
        initial_level = calculate_level(self.prices, self.used_weights)
        self.portfolio.create(initial_tickers, initial_level)
        self.portfolio.save_to_cache(datetime.today())

    def update_portfolio(self):
        for date, row in self.prices.iterrows():
            new_levels = {}
            if date in self.rebalancing_date:
                index = np.nonzero(self.rebalancing_dates == date)[0]
                self.used_weights = self._get_weights(index)
            level = calculate_level(row, self.used_weights)
            # new_levels =
            self.portfolio.update_weights()


    def rebalance_portfolio(self, tickers: list = None, weights: list = None, index=None):
        if tickers is None or weights is None:
            if index is None:
                raise AttributeError('Index needs to be provided while rebalancing using data series')
            tickers = self._get_tickers()
            weights = self._get_weights(index)

        if not bool(self.portfolio.cache):
            raise AttributeError('Portfolio needs to be created before rebalancing can occur')
        latest_holdings_date = max(self.portfolio.cache.keys())
        portfolio_holdings = self.portfolio.cache[latest_holdings_date]
        portfolio_tickers = [item.ticker for item in portfolio_holdings]
        if all(ticker in portfolio_tickers for ticker in tickers):
            new_tickers = dict(zip(portfolio_tickers, weights))
            self.portfolio.update_weights(new_tickers)

    def _get_tickers(self):
        tickers = list(self.units.columns)
        return tickers

    def _get_weights(self, index):
        _weights = self.weights.iloc[index, :]
        return _weights

    @property
    def weights(self):
        if self._weights is None:
            self.calculate_weights()
        return self._weights
